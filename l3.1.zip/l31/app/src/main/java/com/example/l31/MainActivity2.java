package com.example.l31;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Загружаем основной экран
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Получаем данные из базы данных
        DatabaseHelper dbHelper = new DatabaseHelper(this); // Создаем объект для работы с базой
        Cursor cursor = dbHelper.getAllData(); // Забираем все данные

        // Находим место на экране для вывода текста
        TextView textViewData = findViewById(R.id.textViewData);
        StringBuilder sb = new StringBuilder(); // Создаем пустую строку для результатов

        // Есть ли данные?
        if (cursor.moveToFirst()) { // Если есть хотя бы одна запись
            do { // Проходим по всем записям
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID)); // ID записи
                String fio = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_FIO)); // ФИО
                long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TIMESTAMP)); // Время добавления

                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()); // Форматируем дату
                String formattedDate = sdf.format(new Date(timestamp)); // Преобразуем время в удобный формат

                // Добавляем данные в строку для вывода
                sb.append("ID: ").append(id).append("\n");
                sb.append("ФИО: ").append(fio).append("\n");
                sb.append("Время: ").append(formattedDate).append("\n\n");
            } while (cursor.moveToNext()); // Переходим к следующей записи
        } else {
            sb.append("Нет данных"); // Если данных нет, пишем это
        }

        cursor.close(); // Закрываем соединение с базой данных
        textViewData.setText(sb.toString()); // Выводим результат на экран
    }
}

