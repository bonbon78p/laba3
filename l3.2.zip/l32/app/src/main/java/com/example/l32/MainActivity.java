package com.example.l32;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.util.Log;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId") // Аннотация подавляет предупреждение о возможном отсутствии inflate'а id
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Устанавливает layout для activity

        // Находим кнопки в layout'е
        Button buttonShowData = findViewById(R.id.buttonShowData);
        Button buttonAddData = findViewById(R.id.buttonAddData);
        Button buttonUpdateData = findViewById(R.id.buttonUpdateData);

        // Проверка на null (очень рекомендуется)
        if (buttonShowData == null || buttonAddData == null || buttonUpdateData == null) {
            Log.e("MainActivity", "One or more buttons not found!"); // Записываем ошибку в лог
            // Обработка ошибки (например, показать Toast или закрыть Activity)
            return; // Прерываем выполнение, если кнопки не найдены
        }


        // Создаем объект DatabaseHelper для работы с базой данных
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        //Создает базу данных, если её не существует
        dbHelper.onCreateDatabase();
        //Вставляет начальные данные в базу данных
        dbHelper.insertInitialData();


        // Обработчик нажатия кнопки "Показать данные"
        buttonShowData.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity2.class); // Создаем Intent для перехода на другую Activity
            startActivity(intent); // Запускаем другую Activity
        });

        // Обработчик нажатия кнопки "Добавить данные"
        buttonAddData.setOnClickListener(v -> {
            // Добавляем новую запись в базу данных
            dbHelper.insertData("Новый", "Одногруппник", "", System.currentTimeMillis());
            Toast.makeText(this, "Запись добавлена", Toast.LENGTH_SHORT).show(); // Показывает сообщение пользователю
        });

        // Обработчик нажатия кнопки "Обновить данные"
        buttonUpdateData.setOnClickListener(v -> {
            // Обновляем запись в базе данных
            boolean success = dbHelper.updateData("Иванов", "Иван", "Иванович");
            if (success) {
                Toast.makeText(this, "Запись обновлена", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Ошибка обновления записи", Toast.LENGTH_SHORT).show();
            }
        });

        // Устанавливает отступы, учитывающие system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}